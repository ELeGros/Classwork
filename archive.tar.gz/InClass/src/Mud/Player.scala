package Mud

import scala.util.control.Breaks._

class Player(private var inventory: List[Item], private var currrentRoom: Room) {
  def getFromInventory(itemName: String): Option[Item] = {
    var location = -1
    var count = 0
    breakable {
      for (item <- inventory) {
        if (itemName.equals(item.name)) {
          location = count
          break
        }
      }
    }
    Some()
    None
  }

  def addToInventory(item: Item): Unit = {
    inventory = item :: inventory
    None
  }

  def printInventory(): Unit = {
    println("INVENTORY:")
    for (obj <- inventory) println(obj.name)
  }
}
