package Mud

object Main {
  def main(args: Array[String]): Unit = {

  }

}
