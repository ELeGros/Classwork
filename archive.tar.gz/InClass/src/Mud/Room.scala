package Mud

class Room(val name: String, val description: String, private var items: List[Item], val exits: List[Exit]) {
  def printDescription(): Unit = {
    println(description)
  }

  def getExit(dir: String): Option[Exit] = {
    for (exit <- exits) {
      if (exit.direction.equals(dir)) {
        Some(exit)
      }
    }
    None
  }

  def getItem(itemName: String): Option[Item] = {
    for (item <- items) {
      if (item.name.equals(itemName)) {
        Some(item)
      }
    }
    None
  }

  def dropItem(item: Item): Unit = {
    items = item :: items
  }
}

object Room {
  def apply(n: xml.Node): Room = {
   val name = (n \ "@name").mkString
   val i = (n \ "item").toList
   var items = for (item <- i) yield Item(item)
   val e = (n \ "exit").toList
   val exits = for(exit <- e) yield Exit(exit)
   val description = (n \ "description")(0).mkString
    new Room(name, description, items, exits)
  }
}
